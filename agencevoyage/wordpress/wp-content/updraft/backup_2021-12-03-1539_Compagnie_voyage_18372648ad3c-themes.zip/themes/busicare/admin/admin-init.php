<?php
if(is_admin()){
	require BUSICARE_TEMPLATE_DIR . '/admin/inc/class-spicethemes-about-page.php';
}

require BUSICARE_TEMPLATE_DIR . '/admin/inc/plugin-include-control.php';
require BUSICARE_TEMPLATE_DIR . '/admin/inc/include-companion.php';


